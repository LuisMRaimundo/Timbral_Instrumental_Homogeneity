# Architecture (Homogeneity Analyser)

This repository is a **Python package** (`homogeneity_analyser`) under a **src layout**. All application logic lives under `src/homogeneity_analyser/`.

## Layout

| Area | Path | Role |
|------|------|------|
| Score I/O | `homogeneity_analyser/io/` | Pre-parse validation (size, extension, MXL zip metadata), `parse_score()` wrapping music21 |
| Analyzers | `homogeneity_analyser/analyzers/` | **H_TI** / **`H_TI_core`** (`hti.py` — **notation-derived** symbolic timbral–instrumental homogeneity; **register_compactness** = pitch-space span + pairwise **semitone-distance** factors only). Optional **interval-class** / symbolic-blend diagnostics (`symbolic_blend_layers.py`, `taxonomy/symbolic_blend_conditioning.json`) are **orthogonal** to **`H_TI_core`**. Legacy / internal: **H(t)**, **H_timbral**, **U(t)** (`homogeneity.py`, `timbral.py`, `register.py`); timbral helpers **`timbral_sounding_pitch.py`**, **`notation_context.py`**, **`timbre_cross_relations.py`**; family refinements — `docs/H_TIMBRAL_*.md`, `docs/H_TIMBRAL_SCORE_REPRESENTATION.md` |
| Taxonomy | `homogeneity_analyser/taxonomy/` | Part-name → family / canonical instrument (symbolic only, not audio) |
| Services | `homogeneity_analyser/services/` | Orchestration (`analysis_service.py`), CSV assembly (`result_assembly.py`), **structured JSON export** (`json_export.py`), time alignment (`window_pipeline.py`), defaults (`constants.py`) |
| Models | `homogeneity_analyser/models/` | Dataclasses for series results + small enums (`PitchSpaceMode`) |
| Plotting | `homogeneity_analyser/plotting/` | Matplotlib / Plotly figures (`time_series.py`, `summaries.py`, `common.py`) |
| UI | `homogeneity_analyser/ui/` | Gradio app (`gradio_app.py`), callbacks (`callbacks.py` — CSV/plot/**JSON** paths via `output_paths` + `json_export`), upload validation (`validation.py`), static copy (`components.py`) |
| Utils | `homogeneity_analyser/utils/` | Export path helpers (`output_paths.py`) |
| Tests | `tests/` | Pytest + unittest-style modules; **no** `sys.path` hacks — install package first |
| Validation | `validation/` | Scripted checks against annotated fixtures |

## Entry points

- **CLI / module:** `python -m homogeneity_analyser` or console script `homogeneity-analyser` (after `pip install -e .`).
- **Development:** `pip install -e ".[dev]"` then `pytest`, `ruff check`, `ruff format --check`, `mypy`.

## Static typing (mypy)

The rest of the package is type-checked. **`analyzers/homogeneity.py` is excluded** via `pyproject.toml` because mypy 1.17 can hit an internal error while analysing `numpy.histogram2d` in `extract_features`. Runtime behaviour is unchanged; see tests in `tests/test_analyzers.py`.

## Tests and coverage

CI enforces a **minimum total line coverage** (`fail_under` in `pyproject.toml`). Headless tests exercise **analyzers**, **services**, **io**, **models**, **taxonomy**, **utils**, **`plotting/*`** (matplotlib with `Agg`, plotly figures), **`ui/validation.py`**, and **`gradio_app` wiring**: `tests/test_gradio_wiring.py` builds **`build_demo()`** against the real **`gr.Blocks`** graph (asserts four handlers, shared upload input, input/output arity) and against a **minimal fake `gr`** (no `launch`) to record `.click` wiring; **`main()`** is covered via **`cleanup_stale_exports`** + **`build_demo().launch`** mocks. **`callbacks.py`** remains mostly uncovered until callbacks are invoked with real or stubbed scores and mocked exporters.

## Scientific scope (unchanged)

Symbolic MusicXML/MIDI only. **H_TI_core** is **score-based symbolic** homogeneity — **not** measured acoustic or perceptual fusion. **H_timbral** uses notation-encoded part/instrument names, not waveforms. **H_TI-only JSON** uses **`schema_version` `2.9`** (`HTI_EXPORT_SCHEMA_VERSION` in `json_export.py`). See `README.md`, `QUICK_REFERENCE.md`, and `TECHNICAL_MANUAL.md`.
