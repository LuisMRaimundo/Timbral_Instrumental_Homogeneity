# Homogeneity Analyser — documentation

Welcome. This site mirrors the repository Markdown (no mathematical rewrites).

Use the navigation on the left, or start from:

- [README](project_readme.md) — project overview and scope
- [Quick reference](project_quick_reference.md) — operator-facing summary
- [Technical manual](project_technical_manual.md) — methodology, math, CSV/JSON, appendices

Math is rendered with **MathJax 3** (inline `\(...\)`, `$...$`; display `\[...\]`, `$$...$$`) on `pymdownx.arithmatex` spans.
